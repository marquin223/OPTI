<?php include '../app/views/partials/header.php'; ?>
<div class="container">
    <h2>Admin Panel</h2>
    <p>Welcome, <?php echo htmlspecialchars($username); ?>!</p>
    <a href="/logout" class="btn btn-danger">Logout</a>
</div>
